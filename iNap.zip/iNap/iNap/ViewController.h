//
//  ViewController.h
//  iNap
//
//  Created by Khalid Alkhatib on 2/24/16.
//  Copyright © 2016 Khalid Alkhatib. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIWebView *customWebView;


@end

