//
//  ViewController.m
//  iNap
//
//  Created by Khalid Alkhatib on 2/24/16.
//  Copyright © 2016 Khalid Alkhatib. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize customWebView;
- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *path = [[NSBundle mainBundle] pathForResource:@"home" ofType:@"html"];
    
    NSURL *targetURL = [NSURL fileURLWithPath:path];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:targetURL];
    
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
    
    
    
    [customWebView loadRequest:request];
    
    customWebView.scrollView.scrollEnabled = TRUE;
    customWebView.delegate = self;
 customWebView.mediaPlaybackRequiresUserAction = NO;
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
