//
//  AppDelegate.h
//  iNap
//
//  Created by Khalid Alkhatib on 2/24/16.
//  Copyright © 2016 Khalid Alkhatib. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

